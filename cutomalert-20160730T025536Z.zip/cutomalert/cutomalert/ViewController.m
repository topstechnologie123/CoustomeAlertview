//
//  ViewController.m
//  cutomalert
//
//  Created by MACOS on 20/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "CFAlertViewController.h"
#import  "TweetToIncreaseLimitView.h"
#import "CFAlertAction.h"

#define DEFAULT_BTN_TITLE       @"DEFAULT"
#define DEFAULT_BTN_COLOR       [UIColor colorWithRed:41.0/255.0 green:198.0/255.0 blue:77.0/255.0 alpha:1.0]

#define DESTRUCTIVE_BTN_TITLE   @"DESTRUCTIVE"
#define DESTRUCTIVE_BTN_COLOR   [UIColor colorWithRed:255.0/255.0 green:75.0/255.0 blue:75.0/255.0 alpha:1.0]

#define CANCEL_BTN_TITLE        @"CANCEL"
#define CANCEL_BTN_COLOR        [UIColor grayColor]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnclick:(id)sender {
    
    
    UIView *footerView = footerView = [[TweetToIncreaseLimitView alloc] init];
    
    
     UIView *headerView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Money@3x.png"]];
    headerView.contentMode = UIViewContentModeBottom;
    headerView.clipsToBounds = YES;
    headerView.frame = CGRectMake(0, 0, 0, 70.0);
    
    
    
    CFAlertViewController *alert = [CFAlertViewController alertControllerWithTitle:@"This is manual design alert controls "
                                                                           message:@"This is Tops Technologeis cutome app developments "
                                                                     textAlignment:NSTextAlignmentLeft
                                                                    preferredStyle:CFAlertControllerStyleAlert
                                                                        headerView:headerView
                                                                        footerView:footerView
                                                            didDismissAlertHandler:nil];
    
    if (footerView && [footerView isKindOfClass:[TweetToIncreaseLimitView class]]) {
        ((TweetToIncreaseLimitView *)footerView).alertController = alert;
    }
    CFAlertAction *actionDefault = [CFAlertAction actionWithTitle:DEFAULT_BTN_TITLE
                                                            style:CFAlertActionStyleDefault
                                                        alignment:CFAlertActionAlignmentJustified
                                                            color:DEFAULT_BTN_COLOR
                                                          handler:nil];
    [alert addAction:actionDefault];
    
    
    CFAlertAction *actionDestruct = [CFAlertAction actionWithTitle:DESTRUCTIVE_BTN_TITLE
                                                             style:CFAlertActionStyleDestructive
                                                         alignment:CFAlertActionAlignmentJustified
                                                             color:DESTRUCTIVE_BTN_COLOR
                                                           handler:nil];
    [alert addAction:actionDestruct];
    
    
    CFAlertAction *actionCancel = [CFAlertAction actionWithTitle:CANCEL_BTN_TITLE
                                                           style:CFAlertActionStyleCancel
                                                       alignment:CFAlertActionAlignmentJustified
                                                           color:CANCEL_BTN_COLOR
                                                         handler:nil];
    [alert addAction:actionCancel];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
}

- (IBAction)btnaction:(id)sender {
    
    
    UIView *footerView = footerView = [[TweetToIncreaseLimitView alloc] init];
    
    
    UIView *headerView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Money@3x.png"]];
    headerView.contentMode = UIViewContentModeBottom;
    headerView.clipsToBounds = YES;
    headerView.frame = CGRectMake(0, 0, 0, 70.0);
    
    
    
    CFAlertViewController *alert = [CFAlertViewController alertControllerWithTitle:@"This is manual design alert controls "
                                                                           message:@"This is Tops Technologeis cutome app developments "
                                                                     textAlignment:NSTextAlignmentLeft
                                                                    preferredStyle:CFAlertControllerStyleActionSheet
                                                                        headerView:headerView
                                                                        footerView:footerView
                                                            didDismissAlertHandler:nil];
    
    if (footerView && [footerView isKindOfClass:[TweetToIncreaseLimitView class]]) {
        ((TweetToIncreaseLimitView *)footerView).alertController = alert;
    }
    CFAlertAction *actionDefault = [CFAlertAction actionWithTitle:DEFAULT_BTN_TITLE
                                                            style:CFAlertActionStyleDefault
                                                        alignment:CFAlertActionAlignmentJustified
                                                            color:DEFAULT_BTN_COLOR
                                                          handler:nil];
    [alert addAction:actionDefault];
    
    
    CFAlertAction *actionDestruct = [CFAlertAction actionWithTitle:DESTRUCTIVE_BTN_TITLE
                                                             style:CFAlertActionStyleDestructive
                                                         alignment:CFAlertActionAlignmentJustified
                                                             color:DESTRUCTIVE_BTN_COLOR
                                                           handler:nil];
    [alert addAction:actionDestruct];
    
    
    CFAlertAction *actionCancel = [CFAlertAction actionWithTitle:CANCEL_BTN_TITLE
                                                           style:CFAlertActionStyleCancel
                                                       alignment:CFAlertActionAlignmentJustified
                                                           color:CANCEL_BTN_COLOR
                                                         handler:nil];
    [alert addAction:actionCancel];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
    
    
}
@end
